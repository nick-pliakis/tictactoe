CREATE DATABASE  IF NOT EXISTS `tictactoe` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci */;
USE `tictactoe`;
-- MySQL dump 10.13  Distrib 5.5.44, for debian-linux-gnu (x86_64)
--
-- Host: 127.0.0.1    Database: tictactoe
-- ------------------------------------------------------
-- Server version	5.5.44-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `history`
--

DROP TABLE IF EXISTS `history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `history` (
  `game_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_player_name` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `second_player_name` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `player_won` tinyint(1) NOT NULL,
  `game_date` datetime NOT NULL,
  PRIMARY KEY (`game_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `history`
--

LOCK TABLES `history` WRITE;
/*!40000 ALTER TABLE `history` DISABLE KEYS */;
INSERT INTO `history` VALUES (1,'test','test2',1,'2015-07-14 15:24:25'),(2,'Anon_1','Anon_2',1,'2015-08-03 15:20:52'),(3,'nikos','kostas',0,'2015-08-03 15:23:22'),(4,'nikos','Computer',1,'2015-08-03 15:23:37'),(5,'nikos','skynet',1,'2015-08-03 15:29:09'),(6,'Anon_1','Anon_2',1,'2015-08-03 15:32:03'),(7,'Anon_1','Anon_2',-1,'2015-08-03 15:45:12'),(8,'Anon_1','Anon_2',1,'2015-08-03 15:49:35'),(9,'Anon_1','Anon_2',-1,'2015-08-03 15:49:50'),(10,'Anon_1','Computer',1,'2015-08-03 17:36:00'),(11,'nikos','arsenios',0,'2015-08-03 17:36:25'),(12,'nikos','arsenios',-1,'2015-08-03 17:37:03'),(13,'nikos','arsenios',0,'2015-08-03 17:37:24'),(14,'nikos','Skynet',1,'2015-08-03 17:37:42');
/*!40000 ALTER TABLE `history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'tictactoe'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-08-03 17:39:05
